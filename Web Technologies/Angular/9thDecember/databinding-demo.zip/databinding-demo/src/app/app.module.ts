import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import { AppComponent } from './app.component';
import { DatabindComponent } from './databind/databind.component';
import { FontcompComponent } from './fontcomp/fontcomp.component';
import {FormsModule } from '@angular/forms';
import { combineLatest } from 'rxjs';
import { HomeComponent } from './home/home.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { LoginComponent } from './login/login.component';
const rts:Routes=[
   {path:'' , component:HomeComponent},
   {path:'about', component:AboutUsComponent},
   {path:'contact', component:ContactUsComponent},
   {path:'login', component:LoginComponent}
   
];

@NgModule({
  declarations: [
    AppComponent,
    DatabindComponent,
    FontcompComponent,
    HomeComponent,
    AboutUsComponent,
    ContactUsComponent,
    LoginComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    RouterModule.forRoot(rts)
  ],
  providers: [],
  bootstrap: [AppComponent]
})

export class AppModule { }
