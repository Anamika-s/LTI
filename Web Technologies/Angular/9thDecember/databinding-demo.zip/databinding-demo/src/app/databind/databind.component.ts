import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-databind',
  templateUrl: './databind.component.html',
  // template:  `<span [innerHTML]='firstName'> </span>
  // <span> {{firstName}}  </span>
  // <button (click)='showMessage()'> Click Here </button>
  // `,
  
  styleUrls: ['./databind.component.css']
})
export class DatabindComponent implements OnInit {


  constructor() { }
  img1 : string ="/assets/images/Be-agile-237x300.png";
  name:string ="Deepak Sood";
  firstName : string ="Deepak";
  lastName : string ="Sood";
  disable:boolean= false;  
ngOnInit(): void {
  }
  showMessage()
  {
    alert("Hello");
  }
  
}
