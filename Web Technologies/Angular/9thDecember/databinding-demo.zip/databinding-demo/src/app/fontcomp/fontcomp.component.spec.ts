import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FontcompComponent } from './fontcomp.component';

describe('FontcompComponent', () => {
  let component: FontcompComponent;
  let fixture: ComponentFixture<FontcompComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FontcompComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FontcompComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
