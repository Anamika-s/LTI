import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fontcomp',
  templateUrl: './fontcomp.component.html',
  styleUrls: ['./fontcomp.component.css']
})
export class FontcompComponent implements OnInit {


  msg:string ="123";
  text:string="";

  fontSize:number=10;
  
  txtClass:string="";
  
  
  setText(data:any)
  {
    this.fontSize = 10;
    this.text =  data.target.value;
  }

  setSize(size:string)
  {
    if(size=='inc')
      this.fontSize +=10;
    if(size=='dec')
      this.fontSize -=10;
  } 
  setColor(event:any)
  {
    this.txtClass = event.target.value;
    // console.log(this.txtClass);
  }


  setSizeBySlider(event:any)
  {
    this.fontSize = event.target.value;
  }
  constructor() { }

  ngOnInit(): void {
  }

}
