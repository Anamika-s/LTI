import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
image1:string ="/assets/images/Be-agile-237x300.png";
image2:string ="/assets/images/extra-mile-237x300.png";
image3:string ="/assets/images/keep-learning-237x300.png";
image4:string ="/assets/images/push-frontiers-of-innovation-237x300_robo.png";
image5:string ="/assets/images/solve-for-society-237x300_new-237x300.png";
  constructor() { }

  ngOnInit(): void {
  }

}
